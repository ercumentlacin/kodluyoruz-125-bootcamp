const age = () => Math.max(20, parseInt(Math.random() * 70, 10));
const gender = () => (parseInt(Math.random() * 10, 10) % 2 === 0 ? 'F' : 'M');
const companyCode = () =>
  parseInt(Math.random() * 10, 10) % 2 === 0 ? '123' : '456';

const currentTime = new Date().getTime();
const lastOneDays = new Date(currentTime - 24 * 60 * 60 * 1000).getTime();
const lastSevenDays = new Date(currentTime - 7 * 24 * 60 * 60 * 1000).getTime();
const lastOneMonth = new Date(currentTime - 24 * 60 * 60 * 1000).getTime();

console.log({ lastSevenDays });

export const buttonsOfDays = [
  { id: '0', name: 'last 1 day', time: lastOneDays },
  { id: '1', name: 'last 1 week', time: lastSevenDays },
  { id: '2', name: 'last 1 month', time: lastOneMonth },
];

export const aData = [
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-10-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-11-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-12-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-13-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-14-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-15-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-16-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-17-2021'),
  },

  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-20-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-20-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-21-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-22-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-23-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-24-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-25-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-18-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-26-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-27-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('06-28-2021'),
  },
  {
    companyCode: companyCode(),
    gender: gender(),
    age: age(),
    date: new Date('05-20-2021'),
  },
];
