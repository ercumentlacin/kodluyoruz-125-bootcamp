import { memo, useEffect, useState } from 'react';
import { getCompany } from '../../api/company';
import { getMetric } from '../../api/metric';
import Modal from '../Modal';

const AddScreen = (props) => {
  const {
    companys,
    selectedCompany,
    setSelectedCompany,
    buttonsOfDays,
    selectedButton,
    setSelectedButton,
    serviceCompany,
    setServiceCompany,

    setServiceEmployee,
  } = props;

  const [count, setCount] = useState(0);

  const [customDate, setCustomDate] = useState([
    { id: '3', name: 'Date Range Filter', time: '' },
  ]);

  const [dateRange, setDateRange] = useState([
    {
      startDate: new Date(),
      endDate: new Date(),
      key: 'selection',
    },
  ]);

  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);

  // get company
  useEffect(() => {
    const resultCompany = getCompany();
    setServiceCompany(resultCompany);
    if (count === 0) {
      setCount(1);
    }
  }, [companys, count, setServiceCompany]);

  useEffect(() => {
    if (count === 1) {
      setSelectedCompany(serviceCompany?.[0]?.id);
      setCount(2);
    }
  }, [count, serviceCompany, setSelectedCompany]);

  // get metric
  const timeInterval = buttonsOfDays[selectedButton]?.time;

  useEffect(() => {
    if (serviceCompany) {
      function getData() {
        const resultMetric = getMetric({
          timeInterval,
          company: selectedCompany,
          currentTime: new Date().getTime(),
        });
        setServiceEmployee(resultMetric);
      }
      getData();
    }
  }, [
    serviceCompany,
    setServiceEmployee,
    selectedButton,
    selectedCompany,
    timeInterval,
  ]);

  const changeCompany = (e) => {
    setSelectedCompany(e.target.value);
  };

  const onChangeValue = (button) => setSelectedButton(button.target.value);

  return (
    <div className='col-sm-6'>
      <div className='row'>
        {/* select kısmı */}
        <div className='col-sm-12'>
          <select
            className='form-select'
            aria-label='Default select example'
            value={selectedCompany}
            onChange={changeCompany}
          >
            {serviceCompany?.map((company) => {
              return (
                <option key={company.id} value={company.id}>
                  {company.value}
                </option>
              );
            })}
          </select>
        </div>

        {/* buttonlar */}
        <div className='col-sm-12 my-4'>
          <div className='btn-group' role='group'>
            {buttonsOfDays.map((button) => {
              /* seçili buton kontrolü */
              const checked = selectedButton === button.id;

              const className = checked
                ? 'btn btn-primary'
                : 'btn btn-outline-primary';

              return (
                <label className={className} key={button.id}>
                  {button.name}
                  <input
                    type='radio'
                    className='btn-check'
                    name='radio'
                    value={button.id}
                    onChange={onChangeValue}
                    checked={checked}
                  />
                </label>
              );
            })}
            {customDate?.map((button) => {
              const checked = selectedButton === button.id;

              const className = checked
                ? 'btn btn-primary'
                : 'btn btn-outline-primary';

              return (
                <label className={`ms-3 ${className}`} key={button.id}>
                  {dateRange?.length === 1 ? button.name : 'asdasd'}
                  <input
                    type='radio'
                    className='btn-check'
                    name='radio'
                    defaultValue={button.id}
                    onClick={handleShow}
                    onChange={onChangeValue}
                    checked={checked}
                    value={button.id}
                  />
                </label>
              );
            })}
          </div>
        </div>
      </div>
      <Modal
        setCustomDate={setCustomDate}
        dateRange={dateRange}
        setDateRange={setDateRange}
        customDateName={customDate[0].name}
        customDate={customDate}
        show={show}
        setShow={setShow}
      />
    </div>
  );
};

export default memo(AddScreen);
