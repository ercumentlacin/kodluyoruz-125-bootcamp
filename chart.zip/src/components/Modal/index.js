import { memo } from 'react';
import { Button, Modal as ModalR } from 'react-bootstrap';
import { DateRange } from 'react-date-range';

function Modal({
  dateRange,
  setDateRange,
  customDateName,
  show,
  setShow,
  setCustomDate,
  customDate,
}) {
  const handleClose = () => setShow(false);

  const handleSave = () => {
    changeDateRange();
    setShow(false);
  };

  const changeDateRange = () => {
    const { startDate, endDate } = dateRange[0];

    const time = endDate.getTime() - startDate.getTime();

    console.log({ time });

    setCustomDate([
      {
        ...customDate[0],
        name: startDate.toDateString() + ' - ' + endDate.toDateString(),
        time,
      },
    ]);
  };

  return (
    <>
      <ModalR show={show} onHide={handleClose}>
        <ModalR.Header closeButton>
          <ModalR.Title>ModalR heading</ModalR.Title>
        </ModalR.Header>
        <ModalR.Body>
          {' '}
          <DateRange
            editableDateInputs={true}
            onChange={(item) => setDateRange([item.selection])}
            moveRangeOnFirstSelection={false}
            ranges={dateRange}
          />
        </ModalR.Body>
        <ModalR.Footer>
          <Button variant='secondary' onClick={handleClose}>
            Close
          </Button>
          <Button variant='primary' onClick={handleSave}>
            Save Changes
          </Button>
        </ModalR.Footer>
      </ModalR>
    </>
  );
}

export default memo(Modal);
