import { Line } from 'react-chartjs-2';

const Graph = (props) => {
  const { gender, genderText, color, serviceEmployee } = props;

  /* 

      .filter(
      (val) =>
        val.companyCode === selectedCompany &&
        val.gender === gender &&
        val.date.getTime() >= timeInterval &&
        val.date.getTime() <= currentTime
    )



    */

  // const timeInterval = buttonsOfDays[selectedButton].time;

  const obj = { labels: [], data: [] };

  serviceEmployee
    ?.filter((person) => person.gender === gender)
    ?.sort((a, b) => new Date(a.date) - new Date(b.date))
    ?.map((k) => {
      k.label = k.date.getMonth() + 1 + '.' + k.date.getDate();
      // obj['labels'].push(k.label);
      obj['labels'] = obj['labels'].concat(k.label);
      obj['data'].push(k.age);
      return { ...k };
    });

  const data = {
    labels: obj['labels'],
    datasets: [
      {
        label: `# Number of ${genderText}`,
        data: obj['data'],
        fill: false,
        backgroundColor: color,
      },
    ],
  };

  const options = {
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
          },
        },
      ],
    },
  };

  return (
    <div className='col-sm-6'>
      <Line data={data} options={options} />
    </div>
  );
};

export default Graph;
