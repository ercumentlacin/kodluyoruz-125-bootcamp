import { createCompany } from '../../api/company';

import styles from './screen.module.css';

const AddScreen = (props) => {
  const { companys, setCompanys, oInitialName, name, setName } = props;

  const addCompany = (e) => {
    var sId = '';
    if (e.target.value.toLowerCase() === 'sni') {
      sId = '123';
    } else if (e.target.value.toLowerCase() === 'koç') {
      sId = '456';
    } else {
      sId = '789';
    }
    setName({ value: e.target.value, id: sId, timestamp: Date.now() });
  };

  const pushCompany = async (e) => {
    await e.preventDefault();
    await setCompanys([...companys, name]);
    await createCompany({ companyname: companys.value });
    setName(oInitialName);
  };

  return (
    <div className='col-sm-6'>
      <form onSubmit={pushCompany} className='input-group mb-3 '>
        <label className='d-flex align-items-center'>
          <input
            type='text'
            placeholder='İsim ...'
            className='form-control me-2 '
            name='name'
            value={name.value}
            onChange={addCompany}
          />
          <i
            onClick={pushCompany}
            className={`fas fa-plus-circle ${styles.i}`}
          />
        </label>
      </form>
    </div>
  );
};

export default AddScreen;
