import axios from 'axios';

const getURL = process.env.REACT_APP_BASE_URL;

const companyBaseURL = () => getURL + 'company';

export const createCompany = async (input) => {
  try {
    const result = await axios.post(companyBaseURL(), { input });
    if (result.status === 200) {
      return result;
    }
  } catch (err) {
    console.error(err);
  }
};

export const getCompany = () => {
  const data = [
    { value: 'sni', id: '123', timestamp: 1624205288343 },
    { value: 'koç', id: '456', timestamp: 1624205331210 },
  ];
  return data;
  // try {
  //   const result = axios.get(companyBaseURL());
  //   if (result.status === 200) {
  //     return result;
  //   }
  // } catch (err) {}
};
