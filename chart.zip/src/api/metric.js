import { aData } from '../datas/data';

export const getMetric = (params) => {
  if (params.company === undefined || params.company === '') return null;

  const result = aData.filter(
    (val) =>
      val.companyCode === params.company &&
      val.date.getTime() >= params.timeInterval &&
      val.date.getTime() <= params.currentTime
  );

  return result;
  //   try {
  //     const result = await axios.get(metricBaseURL() + params);
  //     if (result.status === 200) {
  //       return result;
  //     }
  //   } catch (err) {
  //     return aData;
  //   }
};
