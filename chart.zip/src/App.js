import { useState } from 'react';
import AddScreen from './components/AddScreen';
import ShowScreen from './components/ShowScreen';
import styles from './app.module.css';
import Graph from './components/Graph';

import { buttonsOfDays } from './datas/data';

const App = () => {
  const [selectedButton, setSelectedButton] = useState(buttonsOfDays[0].id);

  const oInitialName = { value: '', id: '', timestamp: '' };
  const [name, setName] = useState(oInitialName);

  const [companys, setCompanys] = useState([]);

  const [serviceCompany, setServiceCompany] = useState([]);
  const [serviceEmployee, setServiceEmployee] = useState([]);

  const [selectedCompany, setSelectedCompany] = useState(
    serviceCompany?.[0]?.id
  );

  return (
    <div className='container'>
      <div className={`row ${styles.row}`}>
        {/* isim girm alanı */}
        <AddScreen
          companys={companys}
          setCompanys={setCompanys}
          name={name}
          setName={setName}
          oInitialName={oInitialName}
        />

        {/* listeleme ekranı */}
        <ShowScreen
          companys={companys}
          selectedCompany={selectedCompany}
          setSelectedCompany={setSelectedCompany}
          buttonsOfDays={buttonsOfDays}
          selectedButton={selectedButton}
          setSelectedButton={setSelectedButton}
          serviceCompany={serviceCompany}
          setServiceCompany={setServiceCompany}
          serviceEmployee={serviceEmployee}
          setServiceEmployee={setServiceEmployee}
        />

        {/* grap ekranı */}
        <Graph
          serviceEmployee={serviceEmployee}
          serviceCompany={serviceCompany}
          data={companys}
          selectedCompany={selectedCompany}
          buttonsOfDays={buttonsOfDays}
          selectedButton={selectedButton}
          gender={'F'}
          genderText={'Women'}
          color={'rgb(255, 99, 132)'}
        />
        <Graph
          serviceEmployee={serviceEmployee}
          serviceCompany={serviceCompany}
          data={companys}
          selectedCompany={selectedCompany}
          buttonsOfDays={buttonsOfDays}
          selectedButton={selectedButton}
          gender={'M'}
          genderText={'Man'}
          color={'rgb(0, 70, 247)'}
        />
      </div>
    </div>
  );
};
export default App;
